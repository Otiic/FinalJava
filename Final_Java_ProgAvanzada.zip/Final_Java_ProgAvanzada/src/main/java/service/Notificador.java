package service;

import model.Notification;

public interface Notificador {
    void enviar(Notification notification);
}
