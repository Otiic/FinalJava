package service;

public class MedicalRecordService {
    
}
