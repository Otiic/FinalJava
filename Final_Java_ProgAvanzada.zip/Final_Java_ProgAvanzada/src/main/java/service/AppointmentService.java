package service;

public class AppointmentService {
    
}
