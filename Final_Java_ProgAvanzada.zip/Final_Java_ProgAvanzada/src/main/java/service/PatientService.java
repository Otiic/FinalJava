package service;

public class PatientService {
    
}
