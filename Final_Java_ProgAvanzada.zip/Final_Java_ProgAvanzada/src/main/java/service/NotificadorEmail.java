package service;

import model.Notification;

public class NotificadorEmail implements Notificador {

    @Override
    public void enviar(Notification notification) {
    }
}
