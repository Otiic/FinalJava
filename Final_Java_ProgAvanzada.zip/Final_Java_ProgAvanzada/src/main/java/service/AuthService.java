package service;

public class AuthService {
    
}
