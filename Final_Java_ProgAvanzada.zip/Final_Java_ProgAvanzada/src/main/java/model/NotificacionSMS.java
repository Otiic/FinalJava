package model;

public class NotificacionSMS extends Notification {
    
    public NotificacionSMS(String recipient, String message) {
        super(recipient, message);
    }
    
}
