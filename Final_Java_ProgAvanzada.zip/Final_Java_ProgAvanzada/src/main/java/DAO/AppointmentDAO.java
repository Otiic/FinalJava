package DAO;

public class AppointmentDAO {
    
}
